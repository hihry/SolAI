"""Telemetry ingestion package."""
