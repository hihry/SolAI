"""Scoped dependency resolver package."""
