"""Operational alert dispatcher package."""
